package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class VoteKick {

    private final MemoPlugin plugin;
    // hedef -> (oy veren -> zaman)
    private final Map<UUID, Map<UUID, Long>> votes = new ConcurrentHashMap<>();

    public VoteKick(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    public void vote(Player voter, String targetName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            voter.sendMessage("§cO isimde çevrimiçi oyuncu yok.");
            return;
        }
        if (target.equals(voter)) {
            voter.sendMessage("§cKendine oy veremezsin.");
            return;
        }
        if (plugin.king.isKing(target)) {
            voter.sendMessage("§cKrala oy verilemez. Onu öldürerek tahtı alabilirsin!");
            return;
        }

        int required = plugin.getConfig().getInt("votekick.votes-required", 3);
        long window = plugin.getConfig().getLong("votekick.window-seconds", 120) * 1000L;
        long now = System.currentTimeMillis();

        Map<UUID, Long> tv = votes.computeIfAbsent(target.getUniqueId(), k -> new ConcurrentHashMap<>());
        tv.entrySet().removeIf(e -> now - e.getValue() > window);

        if (tv.containsKey(voter.getUniqueId())) {
            voter.sendMessage("§cZaten oy verdin.");
            return;
        }
        tv.put(voter.getUniqueId(), now);

        Bukkit.broadcastMessage("§e" + voter.getName() + " §7→ §c" + target.getName()
                + " §7için oy verdi §f(" + tv.size() + "/" + required + ")");

        if (tv.size() >= required) {
            votes.remove(target.getUniqueId());
            ban(target);
        }
    }

    private void ban(Player target) {
        int hours = plugin.getConfig().getInt("votekick.ban-hours", 24);
        String name = target.getName();
        if (hours > 0) {
            plugin.data.addTempBan(name, System.currentTimeMillis() + hours * 3_600_000L);
        }
        Bukkit.broadcastMessage("§c" + name + " oy çokluğuyla banlandı"
                + (hours > 0 ? " (" + hours + " saat)." : " (kalıcı)."));
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " Oy ile atildi (votekick)");
    }

    /** Suresi dolan gecici banlari kaldirir. */
    public void startTempBanTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            for (Map.Entry<String, Long> e : plugin.data.getTempBans().entrySet()) {
                if (now >= e.getValue()) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pardon " + e.getKey());
                    plugin.data.removeTempBan(e.getKey());
                }
            }
        }, 100L, 1200L);
    }
}
