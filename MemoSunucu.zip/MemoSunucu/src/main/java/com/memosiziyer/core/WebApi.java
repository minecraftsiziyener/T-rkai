package com.memosiziyer.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** GET /api/status ve GET /api/players (can, envanter vb.). */
public class WebApi {

    private final MemoPlugin plugin;
    private HttpServer server;

    public WebApi(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (!plugin.getConfig().getBoolean("web.enabled", true)) return;
        int port = plugin.getConfig().getInt("web.port", 8085);
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext("/api/status", this::handleStatus);
            server.createContext("/api/players", this::handlePlayers);
            server.setExecutor(null);
            server.start();
            plugin.getLogger().info("Web API port " + port + " uzerinde calisiyor.");
        } catch (IOException e) {
            plugin.getLogger().warning("Web API baslatilamadi: " + e.getMessage());
        }
    }

    public void stop() {
        if (server != null) server.stop(0);
    }

    private boolean authorized(HttpExchange ex) {
        String token = plugin.getConfig().getString("web.token", "");
        if (token == null || token.isEmpty()) return true;
        String q = ex.getRequestURI().getRawQuery();
        if (q == null) return false;
        for (String part : q.split("&")) {
            if (part.equals("token=" + token)) return true;
        }
        return false;
    }

    private void write(HttpExchange ex, int code, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void handleStatus(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            write(ex, 401, "{\"error\":\"yetkisiz\"}");
            return;
        }
        JsonObject o = new JsonObject();
        o.addProperty("online", true);
        o.addProperty("playerCount", Bukkit.getOnlinePlayers().size());
        write(ex, 200, o.toString());
    }

    private void handlePlayers(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            write(ex, 401, "{\"error\":\"yetkisiz\"}");
            return;
        }
        JsonArray arr;
        try {
            arr = Bukkit.getScheduler().callSyncMethod(plugin, this::collect).get(5, TimeUnit.SECONDS);
        } catch (Exception e) {
            write(ex, 500, "{\"error\":\"veri toplanamadi\"}");
            return;
        }
        write(ex, 200, arr.toString());
    }

    private JsonArray collect() {
        boolean expose = plugin.getConfig().getBoolean("web.expose-inventory", true);
        JsonArray arr = new JsonArray();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!plugin.register.isAuthed(p)) continue;
            JsonObject o = new JsonObject();
            o.addProperty("name", p.getName());
            String nick = plugin.data.getNick(p.getUniqueId());
            o.addProperty("nick", nick == null ? p.getName() : nick);
            o.addProperty("uuid", p.getUniqueId().toString());
            o.addProperty("king", plugin.king.isKing(p));
            o.addProperty("health", p.getHealth());
            o.addProperty("maxHealth", p.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
            o.addProperty("food", p.getFoodLevel());
            o.addProperty("level", p.getLevel());
            o.addProperty("gameMode", p.getGameMode().toString());
            if (expose) {
                JsonArray inv = new JsonArray();
                ItemStack[] contents = p.getInventory().getContents();
                for (int i = 0; i < contents.length; i++) {
                    ItemStack s = contents[i];
                    if (s == null || s.getType().isAir()) continue;
                    JsonObject item = new JsonObject();
                    item.addProperty("slot", i);
                    item.addProperty("material", s.getType().toString());
                    item.addProperty("amount", s.getAmount());
                    inv.add(item);
                }
                o.add("inventory", inv);
            }
            arr.add(o);
        }
        return arr;
    }
}
