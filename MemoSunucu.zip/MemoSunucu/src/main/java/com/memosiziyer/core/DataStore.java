package com.memosiziyer.core;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataStore {

    private final MemoPlugin plugin;
    private final File file;
    private final YamlConfiguration cfg;

    public DataStore(MemoPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    public synchronized void save() {
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("data.yml kaydedilemedi: " + e.getMessage());
        }
    }

    // ---------- oyuncular ----------
    public boolean isRegistered(UUID id) {
        return cfg.isSet("players." + id + ".nick");
    }

    public String getNick(UUID id) {
        return cfg.getString("players." + id + ".nick");
    }

    public String getIp(UUID id) {
        return cfg.getString("players." + id + ".ip", "");
    }

    public void register(UUID id, String nick, String ip) {
        cfg.set("players." + id + ".nick", nick);
        cfg.set("players." + id + ".ip", ip);
        save();
    }

    public void setIp(UUID id, String ip) {
        if (!isRegistered(id)) return;
        cfg.set("players." + id + ".ip", ip);
        save();
    }

    public boolean isNickTaken(String nick, UUID except) {
        ConfigurationSection sec = cfg.getConfigurationSection("players");
        if (sec == null) return false;
        for (String key : sec.getKeys(false)) {
            if (key.equals(except.toString())) continue;
            String n = sec.getString(key + ".nick");
            if (n != null && n.equalsIgnoreCase(nick)) return true;
        }
        return false;
    }

    // ---------- ev ----------
    public void setHome(UUID id, Location loc) {
        cfg.set("homes." + id, loc);
        save();
    }

    public Location getHome(UUID id) {
        return cfg.getLocation("homes." + id);
    }

    // ---------- kral ----------
    public UUID getKing() {
        String s = cfg.getString("king.uuid");
        if (s == null) return null;
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean kingWasOp() {
        return cfg.getBoolean("king.was-op", false);
    }

    public void setKing(UUID id, boolean wasOp) {
        cfg.set("king.uuid", id.toString());
        cfg.set("king.was-op", wasOp);
        save();
    }

    // ---------- gecici banlar ----------
    public Map<String, Long> getTempBans() {
        Map<String, Long> map = new HashMap<>();
        ConfigurationSection sec = cfg.getConfigurationSection("tempbans");
        if (sec == null) return map;
        for (String k : sec.getKeys(false)) {
            map.put(k, sec.getLong(k));
        }
        return map;
    }

    public void addTempBan(String name, long expiresAt) {
        cfg.set("tempbans." + name, expiresAt);
        save();
    }

    public void removeTempBan(String name) {
        cfg.set("tempbans." + name, null);
        save();
    }
}
