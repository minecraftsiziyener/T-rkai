package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TpMenu implements Listener {

    private final MemoPlugin plugin;
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public TpMenu(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    static class TpHolder implements InventoryHolder {
        final List<UUID> targets = new ArrayList<>();
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    public void open(Player p) {
        TpHolder holder = new TpHolder();
        List<Player> list = new ArrayList<>();
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (t.equals(p)) continue;
            if (!plugin.register.isAuthed(t)) continue;
            list.add(t);
        }
        if (list.isEmpty()) {
            p.sendMessage("§cIşınlanacak başka çevrimiçi oyuncu yok.");
            return;
        }
        if (list.size() > 54) list = new ArrayList<>(list.subList(0, 54));

        int rows = Math.max(1, (int) Math.ceil(list.size() / 9.0));
        Inventory inv = Bukkit.createInventory(holder, rows * 9, "§8Işınlanma Menüsü");
        holder.inv = inv;

        for (int i = 0; i < list.size(); i++) {
            Player t = list.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(t);
            String nick = plugin.data.getNick(t.getUniqueId());
            if (nick == null) nick = t.getName();
            String prefix = plugin.king.isKing(t) ? "§6[Kral] " : "";
            meta.setDisplayName(prefix + "§a" + nick);
            meta.setLore(List.of("§7Hesap: " + t.getName(), "§eTıkla: yanına ışınlan"));
            head.setItemMeta(meta);
            inv.setItem(i, head);
            holder.targets.add(t.getUniqueId());
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof TpHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        int slot = e.getSlot();
        if (slot < 0 || slot >= h.targets.size()) return;
        Player target = Bukkit.getPlayer(h.targets.get(slot));
        p.closeInventory();

        if (target == null || !target.isOnline()) {
            p.sendMessage("§cOyuncu artık çevrimdışı.");
            return;
        }
        long cd = plugin.getConfig().getLong("tp.cooldown-seconds", 5) * 1000L;
        long now = System.currentTimeMillis();
        Long last = lastUse.get(p.getUniqueId());
        if (last != null && now - last < cd) {
            long left = (cd - (now - last)) / 1000L + 1;
            p.sendMessage("§cBekle: " + left + " sn");
            return;
        }
        lastUse.put(p.getUniqueId(), now);
        p.teleportAsync(target.getLocation());
        p.sendMessage("§aIşınlandın: §f" + target.getName());
        target.sendMessage("§e" + p.getName() + " yanına ışınlandı.");
    }
}
