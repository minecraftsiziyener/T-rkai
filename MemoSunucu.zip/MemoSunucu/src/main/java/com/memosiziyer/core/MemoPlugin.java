package com.memosiziyer.core;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class MemoPlugin extends JavaPlugin {

    public DataStore data;
    public RegisterManager register;
    public KingManager king;
    public AiManager ai;
    public TpMenu tpMenu;
    public VoteKick voteKick;
    public WebApi web;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new DataStore(this);
        register = new RegisterManager(this);
        king = new KingManager(this);
        ai = new AiManager(this);
        tpMenu = new TpMenu(this);
        voteKick = new VoteKick(this);
        web = new WebApi(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(register, this);
        pm.registerEvents(king, this);
        pm.registerEvents(tpMenu, this);
        pm.registerEvents(new ChatListener(this), this);

        Commands cmds = new Commands(this);
        String[] names = {"tptr", "ai", "aiapi", "votekick", "kral", "kralduyuru", "ev", "evkur", "rtp"};
        for (String n : names) {
            PluginCommand c = getCommand(n);
            if (c != null) {
                c.setExecutor(cmds);
                c.setTabCompleter(cmds);
            }
        }

        voteKick.startTempBanTask();
        web.start();
        getLogger().info("MemoSunucu aktif.");
    }

    @Override
    public void onDisable() {
        if (web != null) web.stop();
    }
}
