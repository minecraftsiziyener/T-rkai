package com.memosiziyer.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** TurkishAI: Groq (OpenAI uyumlu) uzerinden sohbet. */
public class AiManager {

    private final MemoPlugin plugin;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();
    // oyuncu -> [rol, icerik] ciftleri (ana thread'den erisilir)
    private final Map<UUID, List<String[]>> history = new HashMap<>();
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public AiManager(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean hasKey() {
        String k = plugin.getConfig().getString("ai.api-key", "");
        return k != null && !k.isBlank();
    }

    public String maskedKey() {
        String k = plugin.getConfig().getString("ai.api-key", "");
        if (k == null || k.length() < 8) return "(yok)";
        return k.substring(0, 4) + "****" + k.substring(k.length() - 3);
    }

    public void setKey(String key) {
        plugin.getConfig().set("ai.api-key", key.trim());
        plugin.saveConfig();
    }

    public void ask(Player p, String question) {
        if (!hasKey()) {
            p.sendMessage("§c[TurkishAI] API anahtarı girilmemiş. Yetkili §f/aiapi <anahtar> §cyazmalı.");
            return;
        }
        UUID id = p.getUniqueId();
        long cd = plugin.getConfig().getLong("ai.cooldown-seconds", 5) * 1000L;
        long now = System.currentTimeMillis();
        Long last = lastUse.get(id);
        if (last != null && now - last < cd) {
            p.sendMessage("§c[TurkishAI] Biraz bekle.");
            return;
        }
        lastUse.put(id, now);

        String q = question.trim();
        if (q.isEmpty()) return;
        if (q.length() > 500) q = q.substring(0, 500);
        final String userMsg = q;

        final String key = plugin.getConfig().getString("ai.api-key", "");
        final String url = plugin.getConfig().getString("ai.endpoint", "https://api.groq.com/openai/v1/chat/completions");
        final String model = plugin.getConfig().getString("ai.model", "llama-3.3-70b-versatile");
        final String system = plugin.getConfig().getString("ai.system-prompt", "Turkce kisa cevap ver.");

        JsonArray msgs = new JsonArray();
        msgs.add(msg("system", system));
        for (String[] h : history.getOrDefault(id, new ArrayList<>())) {
            msgs.add(msg(h[0], h[1]));
        }
        msgs.add(msg("user", userMsg));

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", msgs);
        body.addProperty("max_tokens", 300);
        body.addProperty("temperature", 0.7);
        final String bodyStr = body.toString();

        p.sendMessage("§b[TurkishAI] §7Düşünüyorum...");

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String reply = null;
            String error = null;
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(30))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + key)
                        .POST(HttpRequest.BodyPublishers.ofString(bodyStr))
                        .build();
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 200) {
                    reply = JsonParser.parseString(res.body()).getAsJsonObject()
                            .getAsJsonArray("choices").get(0).getAsJsonObject()
                            .getAsJsonObject("message").get("content").getAsString();
                } else {
                    error = "Hata kodu: " + res.statusCode()
                            + (res.statusCode() == 401 ? " (API anahtarı geçersiz)" : "");
                }
            } catch (Exception ex) {
                error = "Bağlantı hatası.";
            }
            final String fr = reply;
            final String fe = error;
            Bukkit.getScheduler().runTask(plugin, () -> deliver(p, userMsg, fr, fe));
        });
    }

    private JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    private void deliver(Player p, String question, String reply, String error) {
        if (!p.isOnline()) return;
        if (reply == null) {
            p.sendMessage("§c[TurkishAI] " + (error == null ? "Cevap alınamadı." : error));
            return;
        }
        List<String[]> h = history.computeIfAbsent(p.getUniqueId(), k -> new ArrayList<>());
        h.add(new String[]{"user", question});
        h.add(new String[]{"assistant", reply});
        while (h.size() > 6) h.remove(0);

        for (String line : wrap(reply)) {
            p.sendMessage("§b[TurkishAI] §f" + line);
        }
    }

    private List<String> wrap(String s) {
        List<String> out = new ArrayList<>();
        for (String raw : s.split("\n")) {
            String line = raw.replace("**", "").trim();
            while (line.length() > 230) {
                int cut = line.lastIndexOf(' ', 230);
                if (cut <= 0) cut = 230;
                out.add(line.substring(0, cut));
                line = line.substring(cut).trim();
            }
            if (!line.isEmpty()) out.add(line);
        }
        return out;
    }
}
