package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final MemoPlugin plugin;

    public ChatListener(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        String msg = e.getMessage();
        e.setFormat("%1$s §7» §f%2$s");

        // "@ai soru" yazinca TurkishAI cevap verir
        if (msg.length() > 4 && msg.regionMatches(true, 0, "@ai ", 0, 4)) {
            String q = msg.substring(4);
            Bukkit.getScheduler().runTask(plugin, () -> plugin.ai.ask(p, q));
        }
    }
}
