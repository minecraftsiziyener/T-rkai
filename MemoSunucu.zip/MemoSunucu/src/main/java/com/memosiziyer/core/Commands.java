package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class Commands implements CommandExecutor, TabCompleter {

    private final MemoPlugin plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> rtpUse = new HashMap<>();

    public Commands(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isAdmin(CommandSender s) {
        if (s instanceof ConsoleCommandSender) return true;
        if (!(s instanceof Player p)) return false;
        for (String a : plugin.getConfig().getStringList("admins")) {
            if (a.equalsIgnoreCase(p.getName())) return true;
        }
        return p.isOp() && !plugin.king.isKing(p);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "tptr" -> {
                if (sender instanceof Player p) plugin.tpMenu.open(p);
                else sender.sendMessage("Sadece oyuncular.");
            }
            case "ai" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Sadece oyuncular."); return true; }
                if (args.length == 0) { p.sendMessage("§eKullanım: /ai <soru>  (veya sohbete @ai soru)"); return true; }
                plugin.ai.ask(p, String.join(" ", args));
            }
            case "aiapi" -> {
                if (!isAdmin(sender)) { sender.sendMessage("§cBu komut için yetkin yok."); return true; }
                if (args.length == 0) {
                    sender.sendMessage("§b[TurkishAI] Anahtar: §f" + plugin.ai.maskedKey() + " §7| Ayarlamak için: /aiapi <anahtar>");
                } else {
                    plugin.ai.setKey(args[0]);
                    sender.sendMessage("§a[TurkishAI] API anahtarı kaydedildi. Artık /ai veya @ai kullanılabilir.");
                }
            }
            case "votekick" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Sadece oyuncular."); return true; }
                if (args.length != 1) { p.sendMessage("§eKullanım: /votekick <oyuncu>"); return true; }
                plugin.voteKick.vote(p, args[0]);
            }
            case "kral" -> kral(sender, args);
            case "kralduyuru" -> {
                boolean ok = sender instanceof ConsoleCommandSender
                        || (sender instanceof Player p && (plugin.king.isKing(p) || isAdmin(sender)));
                if (!ok) { sender.sendMessage("§cSadece kral duyuru yapabilir."); return true; }
                if (args.length == 0) { sender.sendMessage("§eKullanım: /kralduyuru <mesaj>"); return true; }
                String msg = String.join(" ", args);
                Bukkit.broadcastMessage("§6§l[Kral Duyuruyor] §e" + msg);
                for (Player o : Bukkit.getOnlinePlayers()) o.sendTitle("§6Kral Duyuruyor", "§e" + msg, 10, 80, 20);
            }
            case "evkur" -> {
                if (!(sender instanceof Player p)) return true;
                plugin.data.setHome(p.getUniqueId(), p.getLocation());
                p.sendMessage("§aEv noktan kaydedildi. /ev ile dönebilirsin.");
            }
            case "ev" -> {
                if (!(sender instanceof Player p)) return true;
                Location h = plugin.data.getHome(p.getUniqueId());
                if (h == null || h.getWorld() == null) { p.sendMessage("§cÖnce /evkur yaz."); return true; }
                p.teleportAsync(h);
                p.sendMessage("§aEve ışınlandın.");
            }
            case "rtp" -> {
                if (sender instanceof Player p) rtp(p);
            }
            default -> { return false; }
        }
        return true;
    }

    private void kral(CommandSender sender, String[] args) {
        if (args.length == 0) {
            String n = plugin.king.kingName();
            sender.sendMessage(n == null ? "§6[Kral] §7Henüz kral yok." : "§6[Kral] §eŞu anki kral: §f" + n);
            return;
        }
        if (!isAdmin(sender)) { sender.sendMessage("§cYetkin yok."); return; }
        if (args[0].equalsIgnoreCase("yenile")) {
            if (!plugin.king.reroll()) sender.sendMessage("§cÇevrimiçi kayıtlı oyuncu yok.");
        } else if (args[0].equalsIgnoreCase("ver") && args.length >= 2) {
            Player t = Bukkit.getPlayerExact(args[1]);
            if (t == null || !plugin.register.isAuthed(t)) { sender.sendMessage("§cOyuncu bulunamadı."); return; }
            plugin.king.crown(t, "Yetkili tarafından atandı");
        } else {
            sender.sendMessage("§eKullanım: /kral [yenile | ver <oyuncu>]");
        }
    }

    private void rtp(Player p) {
        if (p.getWorld().getEnvironment() != World.Environment.NORMAL) {
            p.sendMessage("§cRTP sadece Overworld'de çalışır.");
            return;
        }
        long cd = plugin.getConfig().getLong("rtp.cooldown-seconds", 60) * 1000L;
        long now = System.currentTimeMillis();
        Long last = rtpUse.get(p.getUniqueId());
        if (last != null && now - last < cd) {
            p.sendMessage("§cBekle: " + ((cd - (now - last)) / 1000L + 1) + " sn");
            return;
        }
        int r = Math.max(100, plugin.getConfig().getInt("rtp.radius", 2000));
        World w = p.getWorld();
        Location center = w.getSpawnLocation();
        Location dest = null;
        for (int i = 0; i < 10 && dest == null; i++) {
            int x = center.getBlockX() + random.nextInt(r * 2 + 1) - r;
            int z = center.getBlockZ() + random.nextInt(r * 2 + 1) - r;
            int y = w.getHighestBlockYAt(x, z);
            Block b = w.getBlockAt(x, y, z);
            if (b.isLiquid()) continue;
            dest = new Location(w, x + 0.5, y + 1, z + 0.5);
        }
        if (dest == null) { p.sendMessage("§cUygun yer bulunamadı, tekrar dene."); return; }
        rtpUse.put(p.getUniqueId(), now);
        p.teleportAsync(dest);
        p.sendMessage("§aRastgele bir yere ışınlandın.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("votekick") && args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (name.equals("kral")) {
            if (args.length == 1) { out.add("yenile"); out.add("ver"); }
            else if (args.length == 2 && args[0].equalsIgnoreCase("ver")) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            }
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
