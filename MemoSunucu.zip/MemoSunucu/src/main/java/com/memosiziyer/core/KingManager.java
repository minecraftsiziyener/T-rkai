package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class KingManager implements Listener {

    private final MemoPlugin plugin;
    private final Random random = new Random();
    private boolean internalGm = false;

    public KingManager(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isKing(Player p) {
        return p.getUniqueId().equals(plugin.data.getKing());
    }

    private boolean bypass(Player p) {
        return p.hasPermission("memo.king.bypass");
    }

    public String kingName() {
        UUID k = plugin.data.getKing();
        if (k == null) return null;
        String nick = plugin.data.getNick(k);
        if (nick != null) return nick;
        return Bukkit.getOfflinePlayer(k).getName();
    }

    // ---------- gorunum ----------
    public void decorate(Player p) {
        String nick = plugin.data.getNick(p.getUniqueId());
        if (nick == null) return;
        String prefix = isKing(p) ? "§6[Kral] " : "";
        p.setDisplayName(prefix + "§f" + nick + "§r");
        p.setPlayerListName(prefix + "§f" + nick);
    }

    // ---------- secim ----------
    private List<Player> pool() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.register.isAuthed(p) && plugin.data.isRegistered(p.getUniqueId())) {
                list.add(p);
            }
        }
        return list;
    }

    public void onAuthenticated(Player p) {
        UUID k = plugin.data.getKing();
        if (k == null) {
            int min = plugin.getConfig().getInt("king.min-players-for-random", 2);
            List<Player> pool = pool();
            // giren oyuncu henuz "authed" sayilmayabilir, listeye ekle
            if (!pool.contains(p) && plugin.data.isRegistered(p.getUniqueId())) pool.add(p);
            if (pool.size() >= min) {
                crown(pool.get(random.nextInt(pool.size())), "Rastgele seçildi!");
            } else {
                p.sendMessage("§6[Kral] §7Kral, en az " + min + " kayıtlı oyuncu olunca rastgele seçilecek.");
            }
        } else if (k.equals(p.getUniqueId())) {
            if (!p.isOp()) p.setOp(true);
        }
    }

    public boolean reroll() {
        List<Player> pool = pool();
        if (pool.isEmpty()) return false;
        crown(pool.get(random.nextInt(pool.size())), "Rastgele seçildi!");
        return true;
    }

    public void crown(Player np, String reason) {
        UUID oldId = plugin.data.getKing();
        if (oldId != null && oldId.equals(np.getUniqueId())) return;

        if (oldId != null) {
            if (!plugin.data.kingWasOp()) {
                OfflinePlayer old = Bukkit.getOfflinePlayer(oldId);
                old.setOp(false);
            }
        }

        boolean wasOp = np.isOp();
        plugin.data.setKing(np.getUniqueId(), wasOp);
        np.setOp(true);

        if (np.getGameMode() == GameMode.CREATIVE || np.getGameMode() == GameMode.SPECTATOR) {
            internalGm = true;
            np.setGameMode(GameMode.SURVIVAL);
            internalGm = false;
        }

        String name = plugin.data.getNick(np.getUniqueId());
        if (name == null) name = np.getName();
        Bukkit.broadcastMessage("§6§l[KRAL] §e" + name + " §6artık kral! §7(" + reason + ")");
        np.sendTitle("§6Kral!", "§eKraliyet yetkilerine sahipsin", 10, 80, 20);

        decorate(np);
        if (oldId != null) {
            Player oldOnline = Bukkit.getPlayer(oldId);
            if (oldOnline != null) decorate(oldOnline);
        }
    }

    // ---------- kral oldurulunce ----------
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        if (!isKing(victim)) return;
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;
        if (!plugin.register.isAuthed(killer) || !plugin.data.isRegistered(killer.getUniqueId())) return;
        crown(killer, "Eski kralı öldürdü!");
    }

    // ---------- kisitlamalar ----------
    private Set<String> blocked() {
        Set<String> set = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("king.blocked-commands")) {
            set.add(s.toLowerCase(Locale.ROOT));
        }
        return set;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!isKing(p) || bypass(p)) return;
        String raw = e.getMessage().substring(1).trim().toLowerCase(Locale.ROOT);
        if (raw.isEmpty()) return;
        String cmd = raw.split("\\s+")[0];
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (blocked().contains(cmd)) {
            e.setCancelled(true);
            p.sendMessage("§cKral bu komutu kullanamaz: /" + cmd);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onGameMode(PlayerGameModeChangeEvent e) {
        if (internalGm) return;
        Player p = e.getPlayer();
        if (!isKing(p) || bypass(p)) return;
        GameMode g = e.getNewGameMode();
        if (g == GameMode.CREATIVE || g == GameMode.SPECTATOR) {
            e.setCancelled(true);
            p.sendMessage("§cKral yaratıcı/izleyici moda geçemez.");
        }
    }
}
