package com.memosiziyer.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RegisterManager implements Listener {

    private enum State { MENU, PASSWORD }

    private final MemoPlugin plugin;
    private final Map<UUID, State> pending = new ConcurrentHashMap<>();
    private final Map<UUID, String> chosen = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> attempts = new ConcurrentHashMap<>();

    public RegisterManager(MemoPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isPending(Player p) {
        return pending.containsKey(p.getUniqueId());
    }

    public boolean isAuthed(Player p) {
        return !isPending(p);
    }

    private static String ip(Player p) {
        if (p.getAddress() == null || p.getAddress().getAddress() == null) return "";
        return p.getAddress().getAddress().getHostAddress();
    }

    // ---------------- menu holder ----------------
    static class MenuHolder implements InventoryHolder {
        final List<String> names;
        Inventory inv;

        MenuHolder(List<String> names) {
            this.names = names;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    // ---------------- giris ----------------
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();

        if (plugin.data.isRegistered(id)) {
            if (ip(p).equals(plugin.data.getIp(id))) {
                finish(p);
                return;
            }
            // IP degismis: sifreyi tekrar iste
            chosen.put(id, plugin.data.getNick(id));
            pending.put(id, State.PASSWORD);
        } else {
            pending.put(id, State.MENU);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> prompt(p), 10L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        pending.remove(id);
        chosen.remove(id);
        attempts.remove(id);
    }

    private void prompt(Player p) {
        if (!p.isOnline()) return;
        State s = pending.get(p.getUniqueId());
        if (s == null) return;
        if (s == State.MENU) {
            openMenu(p);
        } else {
            String nick = chosen.get(p.getUniqueId());
            p.sendTitle("§eŞifre", "§7Sohbete şifreyi yaz", 10, 200, 10);
            p.sendMessage("§e[Kayıt] §f" + nick + " §7olarak devam etmek için şifreyi sohbete yaz.");
        }
    }

    private void openMenu(Player p) {
        List<String> names = new ArrayList<>(plugin.getConfig().getStringList("register.members"));
        if (names.isEmpty()) names.add(p.getName());
        if (names.size() > 54) names = new ArrayList<>(names.subList(0, 54));

        MenuHolder holder = new MenuHolder(names);
        int rows = Math.max(1, (int) Math.ceil(names.size() / 9.0));
        Inventory inv = Bukkit.createInventory(holder, rows * 9, "§8Adını seç");
        holder.inv = inv;

        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            boolean taken = plugin.data.isNickTaken(n, p.getUniqueId());
            ItemStack item = new ItemStack(taken ? Material.BARRIER : Material.NAME_TAG);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName((taken ? "§c" : "§a") + n);
            meta.setLore(List.of(taken ? "§7Bu isim alınmış" : "§7Tıkla ve bu ismi seç"));
            item.setItemMeta(meta);
            inv.setItem(i, item);
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof MenuHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        int slot = e.getSlot();
        if (slot < 0 || slot >= h.names.size()) return;
        String nick = h.names.get(slot);

        if (plugin.data.isNickTaken(nick, p.getUniqueId())) {
            p.sendMessage("§cBu isim başkası tarafından alınmış.");
            return;
        }
        UUID id = p.getUniqueId();
        chosen.put(id, nick);
        pending.put(id, State.PASSWORD);
        Bukkit.getScheduler().runTask(plugin, () -> {
            p.closeInventory();
            prompt(p);
        });
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof MenuHolder)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        if (pending.get(p.getUniqueId()) == State.MENU) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline() && pending.get(p.getUniqueId()) == State.MENU) openMenu(p);
            }, 2L);
        }
    }

    // ---------------- sifre ----------------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        State s = pending.get(p.getUniqueId());
        if (s == null) return;
        e.setCancelled(true);
        if (s != State.PASSWORD) return;
        String msg = e.getMessage();
        Bukkit.getScheduler().runTask(plugin, () -> checkPassword(p, msg));
    }

    private void checkPassword(Player p, String msg) {
        UUID id = p.getUniqueId();
        if (pending.get(id) != State.PASSWORD) return;
        String expected = plugin.getConfig().getString("register.password", "");

        if (!expected.isEmpty() && msg.trim().equals(expected)) {
            String nick = chosen.get(id);
            if (!plugin.data.isRegistered(id)) {
                if (nick == null || plugin.data.isNickTaken(nick, id)) {
                    p.sendMessage("§cBu isim artık alınmış, tekrar seç.");
                    pending.put(id, State.MENU);
                    prompt(p);
                    return;
                }
                plugin.data.register(id, nick, ip(p));
            }
            finish(p);
        } else {
            int a = attempts.merge(id, 1, Integer::sum);
            if (a >= 3) {
                p.kickPlayer("§cÇok fazla yanlış şifre girdin.");
            } else {
                p.sendMessage("§cYanlış şifre! (" + a + "/3)");
            }
        }
    }

    private void finish(Player p) {
        UUID id = p.getUniqueId();
        pending.remove(id);
        chosen.remove(id);
        attempts.remove(id);
        plugin.data.setIp(id, ip(p));
        p.resetTitle();
        plugin.king.onAuthenticated(p);
        plugin.king.decorate(p);
        p.sendMessage("§aHoş geldin, §f" + plugin.data.getNick(id) + "§a!");
    }

    // ---------------- dondurma ----------------
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!isPending(e.getPlayer())) return;
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            Location fixed = f.clone();
            fixed.setYaw(t.getYaw());
            fixed.setPitch(t.getPitch());
            e.setTo(fixed);
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isPending(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && isPending(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && isPending(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (isPending(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cÖnce kaydını tamamla.");
        }
    }
}
