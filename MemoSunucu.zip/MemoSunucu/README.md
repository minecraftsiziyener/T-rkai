# MemoSunucu (Paper 1.20.6 / Java 21)

Tek plugin icinde: Kayit sistemi, Kral sistemi, TurkishAI, /tptr menusu, /votekick, /ev /rtp ve web API.

## Kurulum
1. Bu klasoru GitHub reposuna yukle (Actions otomatik derler).
2. Actions -> Artifacts -> `MemoSunucu.jar` indir, `plugins/` klasorune koy, sunucuyu yeniden baslat.
3. `plugins/MemoSunucu/config.yml` icinde **register.password** ve **register.members** listesini duzenle.
4. Oyunda: `/aiapi <groq_anahtari>` (yetkili) -> `/ai soru` veya sohbete `@ai soru`.

## Ozellikler
- Giriste menu: adini sec -> ortak sifreyi sohbete yaz. Kayit bitene kadar hareket/komut/blok yok. IP degisirse sifre tekrar sorulur.
- Kral: yeterli kayitli oyuncu olunca rastgele secilir, OP olur. Krali oldurenin kral olur. Kral gamemode/give/item/execute vb. kullanamaz (config'den duzenlenir).
- /tptr: cevrimici oyuncularin kafalarini gosteren menu, tikla ve yanina isinlan.
- /votekick <oyuncu>: 2 dk icinde 3 oy = ban (24 saat). Krala oy verilemez.
- /ev /evkur /rtp /kral /kralduyuru
- Web API: /api/status, /api/players (can, envanter). Port disariya acik degilse siteden erisilemez.
